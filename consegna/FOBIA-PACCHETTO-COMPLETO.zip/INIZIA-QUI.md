# FOBIA — consegna aggiornata

Aprire ANTEPRIMA/FOBIA.html nel browser per una revisione autonoma.
Il progetto da pubblicare è in fobia/. Leggere fobia/LEGGIMI-DEPLOY.md.
Node.js 24: npm ci, npm run build, npm start. Per GitHub Pages: npm run build:pages.
Contenuti e URL: fobia/src/lib/event.ts. XCEED, WhatsApp e Maps sono configurati.
NOH DINNER SHOW, ingresso Party dalle 23:30, Door Entry con 1 drink, quantità pass non visibili.
Build, TypeScript e 17 verifiche Playwright superati.
L'attivazione esterna di GitHub Pages resta da confermare; il branch gh-pages contiene la build statica.
