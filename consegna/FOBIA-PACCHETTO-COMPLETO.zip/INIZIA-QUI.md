# FOBIA PIETRASOLE — pacchetto completo

1. Leggere fobia/LEGGIMI-DEPLOY.md.
2. Dalla cartella fobia eseguire npm ci, poi npm run dev per lavorare.
3. Inserire dominio e link XCEED in fobia/src/lib/event.ts.
4. Per produzione: npm run build, quindi npm start, oppure deploy del progetto Next.js su Vercel.

ANTEPRIMA/FOBIA.html si apre direttamente nel browser per confrontare il risultato attuale. È un’istantanea per revisione; il progetto da pubblicare è nella cartella fobia.

Il pacchetto comprende sorgenti, lockfile, tutti gli asset originali, font tramite dipendenza npm e relativa licenza, test e istruzioni. Dipendenze installate e build vengono rigenerate sul computer/server del programmatore.

Verifica integrità: SHA256SUMS.txt.
