# FOBIA PIETRASOLE — consegna finale aggiornata

Leggere fobia/LEGGIMI-DEPLOY.md. Nella cartella fobia: npm ci, poi npm run dev. Produzione: npm run build e npm start, oppure deploy Next.js su Vercel.

Configurare dominio e link XCEED in fobia/src/lib/event.ts prima della pubblicazione. WhatsApp cena/tavoli e Maps sono già configurati.

ANTEPRIMA/FOBIA.html si apre nel browser. Include tutti gli asset originali, data grafica centrata nell’intestazione, testo grafico sotto il payoff, sfondi NŌH/Party e spazi più compatti su mobile. È un’istantanea per revisione; per pubblicare usare il progetto Next.js nella cartella fobia.

Inclusi sorgenti, lockfile, originali, licenza font, test e istruzioni. Verificati build, TypeScript e 16 test. SHA256SUMS.txt permette di verificare l’integrità dei file.
