# FOBIA PIETRASOLE — pacchetto completo aggiornato

Leggere fobia/LEGGIMI-DEPLOY.md. Nella cartella fobia: npm ci, poi npm run dev per lavorare. Per produzione: npm run build e npm start, oppure deploy Next.js su Vercel.

Configurare dominio e link XCEED in fobia/src/lib/event.ts prima della pubblicazione. WhatsApp e Maps sono già configurati.

ANTEPRIMA/FOBIA.html si apre direttamente nel browser. Include le ultime modifiche: grafica TESTO-HERO centrata e responsive sotto il payoff, e sfondo illustrato NŌH Experience con ritagli e sfumature. È un’istantanea per revisione; il progetto da pubblicare è nella cartella fobia.

Sono inclusi sorgenti, lockfile, asset originali, licenza font, test e istruzioni. Verificati build, TypeScript e 15 test. SHA256SUMS.txt verifica l’integrità dei file.
