# FOBIA PIETRASOLE — progetto e pubblicazione

Leggere fobia/LEGGIMI-DEPLOY.md. Nella cartella fobia: npm ci, npm run dev. Produzione Node/Vercel: npm run build e npm start. Build GitHub Pages: npm run build:pages, output out/.

Checkout XCEED, WhatsApp cena/tavoli e Maps sono configurati. Per Node/Vercel impostare il dominio; la build Pages usa https://vhagakure.github.io/fobia/.

Il branch gh-pages contiene già il sito compilato. Per renderlo pubblico occorre attivare GitHub Settings → Pages → Deploy from a branch → gh-pages → /(root). Il caricamento del branch non equivale all’attivazione dell’hosting.

ANTEPRIMA/FOBIA.html è un’istantanea per revisione. Il progetto da pubblicare è nella cartella fobia. Inclusi sorgenti, lockfile, originali, licenza font, test e istruzioni. Verificati build Node, TypeScript, 16 test e build statica con controlli responsive e cambio release. SHA256SUMS.txt verifica l’integrità dei file.
